


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <title>Coming Soon Godrej Properties Godrej Reserve Devanahalli Bangalore </title>

    <meta name="keywords" content="Coming Soon Godrej Properties Godrej Reserve Devanahalli Bangalore,  Premium  apartments, Godrej Properties Bangalore ,  Godrej Properties Bangalore Godrej Reserve Devanahalli Bangalore" />
    <meta name="description" content="Coming Soon Godrej Properties Godrej Reserve Devanahalli Bangalore in india with the starting prelaunch booking of ..Enquiry now" />
    <!-- Bootstrap CSS -->
      <link rel="shortcut icon" href="images/favicon.ico" />
    <link rel="stylesheet" href="css/bootstrap.min.css" >
    <link href="css/app.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="js/fancybox-n/jquery.fancybox.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">



<!-- Global site tag (gtag.js) - Google Ads: 831186308 --> 
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-831186308"></script> 
<script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'AW-831186308'); </script>



  </head><body>
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light  fixed-top  " id="nav-main">
      <a class="navbar-brand" href="index.php"><img src="images/logo.png" class="img-fluid" alt="Godrej Properties Reserve at Bengaluru"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto" >
        </ul>
        <ul class="navbar-nav my-2 my-lg-0 stickyMenum" id="mainNava">
          <li class="nav-item  ">
            <a class="nav-link" href="#home" title=" Godrej Properties Reserve at Bengaluru " ><i class="material-icons micon m-iconss">home</i></a>
          </li>
           <li class="nav-item d-block d-sm-none">
            <a class="nav-link top" href="#overview" title=" Godrej Properties Reserve at Bengaluru "> <i class="material-icons  m-iconss">assignment</i>Overview</a>
          </li>
          <li class="nav-item d-block d-sm-none">
            <a class="nav-link top" href="#amenities" title=" Godrej Properties Reserve at Bengaluru  Amenities"><i class="material-icons m-iconss">ballot</i> Amenities</a>
          </li>
          <!--  <li class="nav-item">
            <a class="nav-link" href="gallery.php" title=" Godrej Properties Reserve at Bengaluru  Gallery">Gallery</a>
          </li> -->
           <li class="nav-item d-block d-sm-none">
            <a class="nav-link top" href="#plans" title=" Godrej Properties Reserve at Bengaluru  Plans"><i class="material-icons m-iconss">view_quilt</i> Plans</a>
          </li>
            <li class="nav-item d-block d-sm-none">
            <a class="nav-link top" href="#location" title=" Godrej Properties Reserve at Bengaluru  Location"><i class="material-icons m-iconss">location_on</i> Location</a>
          </li>
            <li class="nav-item d-block d-sm-none">
            <a class="nav-link top" href="#costing" title=" Godrej Properties Reserve at Bengaluru  Price"><i class="material-icons m-iconss">&#8377;</i> Price</a>
          </li>
          <li class="nav-item d-block d-sm-none">
            <a class="nav-link top" href="#virtualtour" title=" Godrej Properties Reserve at Bengaluru  Virtual Site Visit"><i class="material-icons m-iconss">video_library</i> Virtual Site Visit</a>
          </li>
          <li class="nav-item d-block d-sm-none">
            <a class="nav-link" href="#" data-toggle="modal" data-target="#ebook"><i class="material-icons m-iconss">picture_as_pdf</i> Brochure </a>
          </li>
          <li class="nav-item">
            <a class="nav-link"   href="#" data-toggle="modal" data-target="#enquirenow"><i class="material-icons micon m-iconss"> email </i> Enquire </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link contact-no" href="tel:7506010422"><i class="material-icons micon m-iconss">  perm_phone_msg </i> +91 7506010422</a>
          </li>
          <li class="nav-item b-logo">
            <img src="images/b-logo.jpg" class="img-fluid" alt=" Logo">
          </li>
        </ul>
      </div>
    </nav>
    
  </header>
  <div class="sidemenu-holder d-none d-md-block d-lg-block">
  <ul class="navbar-nav my-2 my-lg-0 stickyMenu" id="mainNav">
       <!--    <li class="nav-item  ">
            <a class="nav-link" href="#home" title=" Godrej Properties Reserve at Bengaluru " ><i class="material-icons micon">home</i></a>
          </li> -->
          <li class="nav-item ">
            <a class="nav-link top" href="#overview" title=" Godrej Properties Reserve at Bengaluru "> <i class="material-icons  m-iconss">
assignment
</i>Overview</a>
          </li>
          <li class="nav-item">
            <a class="nav-link top" href="#amenities" title=" Godrej Properties Reserve at Bengaluru  Amenities"><i class="material-icons m-iconss">
ballot
</i> Amenities</a>
          </li>
          <!--  <li class="nav-item">
            <a class="nav-link" href="gallery.php" title=" Godrej Properties Reserve at Bengaluru  Gallery">Gallery</a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link top" href="#plans" title=" Godrej Properties Reserve at Bengaluru  Plans"><i class="material-icons m-iconss">
view_quilt
</i> Plans</a>
          </li>
          <li class="nav-item">
            <a class="nav-link top" href="#location" title=" Godrej Properties Reserve at Bengaluru  Location"><i class="material-icons m-iconss">
location_on
</i> Location</a>
          </li>
          <li class="nav-item">
            <a class="nav-link top" href="#costing" title=" Godrej Properties Reserve at Bengaluru  Price"><i class="material-icons m-iconss">&#8377;</i> Price</a>
          </li>
          <li class="nav-item">
            <a class="nav-link top" href="#virtualtour" title=" Godrej Properties Reserve at Bengaluru  Virtual Site Visit"><i class="material-icons m-iconss">video_library</i> Virtual Site Visit</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="modal" data-target="#ebook"><i class="material-icons m-iconss">
              picture_as_pdf
            </i> Brochure </a>
          </li>
        
         <!--  <li class="nav-item ">
            <a class="nav-link contact-no" href="tel:7506010422"><i class="material-icons m-iconss">
              perm_phone_msg
            </i> +91 7506010422</a>
          </li> -->
        <!--   <li class="nav-item b-logo">
            <img src="images/logo1.png" class="img-fluid" alt=" Logo">
          </li> -->
        </ul>
      </div>

  <div class="inner-overlay wave tracked" id="home">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
      <!--   <li data-target="#carouselExampleSlidesOnly" data-slide-to="0" class="active"></li> -->
       <!--  <li data-target="#carouselExampleSlidesOnly" data-slide-to="1"></li>
        <li data-target="#carouselExampleSlidesOnly" data-slide-to="2"></li> -->
      </ol>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img class="d-block w-100 yehlo" src="images/bg-image.jpg" alt="First slide">
        </div>
    <!--     <div class="carousel-item">
          <img class="d-block w-100 yehlo" src="images/bg-image1.jpg" alt="First slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100 yehlo" src="images/bg-image2.jpg" alt="First slide">
        </div> -->
      </div>
    </div>
  </div>
  <div class="clearfix"></div>
  <div class="intro-box">
    <h1 class="main-message bookings" style="font-weight: 500;
    font-size: 20px;
    border: none;
    border-bottom: 1px solid #dfdfdf;
    margin-bottom: 10px;
    color: #7caf41;
    display: block;
    margin: 0 -10px 10px;
    padding: 0px 10px 5px;
    text-align: left;" > Coming Soon 
    </h1>
    <span style="font-size: 15px; display: block; color: #3a3a3a;  padding-bottom: 0; ">
      <span style="display: block; font-size: 21px; color: #000000; font-weight: 500; margin-top: 5px;">Godrej Properties </span>First-ever Plotted Development.</span>
      <span style="display: block; font-size: 21px; color: #78ab3d; font-weight: 500; margin-top: 5px;">Godrej Reserve </span>at Devanahalli, Bengaluru</span>
      <div class="ch-bot">
  <!--       <ul style="font-size: 12px; padding: 0 20px; margin-bottom: 10px; list-style: none; text-align: left; border: 1px solid #ffffff;  padding: 5px 20px; box-shadow: 0 0 29px -3px #00000036; background: #fff; 
         border-radius: 4px;" >
         <li style="position: relative;">
          <i class="material-icons" style="top: -4px; position: absolute; left: -25px; line-height: -12px; color: #bf296d;">arrow_right </i> 
            Plot Area :  13512.71 SQ.MT (as per document)
         </li>
        <li style="position: relative;"><i class="material-icons" style="    top: -4px;
          position: absolute;
          left: -25px;
          
          line-height: -12px;
          color: #bf296d;">
          arrow_right
        </i>Total Units : 160  </li>
          <li style="position: relative;"><i class="material-icons" style="    top: -4px;
            position: absolute;
            left: -25px;
            
            line-height: -12px;
            color: #bf296d;">
            arrow_right
          </i>Club House : G+2 Floors</li>
          <li style="position: relative;"><i class="material-icons" style="    top: -4px;
            position: absolute;
            left: -25px;
            
            line-height: -12px;
            color: #bf296d;">
            arrow_right
          </i>Car Parking (289) - Surface parking (6)</li>
          
        </ul> -->
        <!--   <p class="offerprice" style="    margin: 0; margin-bottom: 5px;">Site address : <br>Shell Colony, Sahakar nagar 1, Chembur, Mumbai</p>
        --> <p class="offerprice" style=" margin: 0;">Premium Residential Plots Starts</p>
        
        <a data-target="#price" data-toggle="modal" class="btn button-3d" title=" Godrej Properties Reserve at Bengaluru Enquire now" style="margin: 10px 0 15px;">&#8377; 44 Lakhs onwards</a>
        <p class="offerprice" style="    margin-bottom: 0; font-size: 10px; font-weight: bold;">RERA Acknowledgement Number: <br>ACK/KA/RERA/1250/303/PR/181023/002738</p>
      </div>
    </div>
    <div class="bg-form d-none d-sm-block">
      <h3 class="form-heading">Register Online for your Interest</h3>
      <form action="#" method="POST" id="query_form_enquiry">
        <input type="hidden" id="name_enquiry" name="name_enquiry_land">
        <div class="form-group groupmaterial">
          
          <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="name_enq_ld" required="required">
          <span class="highlight"></span>
          <span class="bar"></span>
          <label for="forname">Name</label>
        </div>
        <div class="form-group groupmaterial">
          
          <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="email_enq_ld" required="required">
          <span class="highlight"></span>
          <span class="bar"></span>
          <label for="exampleInputEmail1">Email address</label>
          
        </div>
        <div class="form-group groupmaterial" style="    margin-bottom: 12px;">
          
          <input type="text" class="form-control" id="formobile" aria-describedby="emailHelp" placeholder="" name="contact_enq_ld" required="required">
          <span class="highlight"></span>
          <span class="bar"></span>
          <label for="formobile">Mobile no.</label>
        </div>
        <button type="submit" class="btn  button-3d">Register Interest</button>
      </form>
    </div>
    <div class="clearfix"></div>
    <section class="bg-image2 tracked" id="overview">
      <div class="container">
        <div class="col-sm-12  col-lg-9 col-md-9 ">
          <div class="wrapper-inner-text">
            <h1 style="" class="">Godrej Reserve Devenahalli, Bangalore</h1>
            <!-- <div style="    font-size: 18px;
              color: #3c3c3c;
              font-weight: 100;
            margin-bottom: 20px;">Live the Signature Life at Greater Noida’s most finest address</div> -->
            <div class="row">
              
              <div class="col col-lg-12 col-md-12 ">
                  <p class="text-justify">Spread over a sprawling 92.7 acres, a quick drive from Kempegowda International Airport, is a land of diverse contours, all dressed in varied hues of green. With over 6 acres of forest experience, 2 clubhouses, organic farms, a host of community parks, and the cleanest air in the city, this isn’t a place to build a mere home. It’s a place to put down your roots for generations to come, a place to build upon your legacy, and give it a place to call home.</p>

               <p class="text-justify">Welcome to Godrej Reserve, a forest-themed plotted development nestled between Kempegowda International Airport and the iconic Nandi Hills, with plots ranging from 1200 Sq.ft. (111.48 Sq.m.) to 3200 Sq.ft. (297.29 Sq.m.).</p>
                <h2>Project Highlights</h2>
                <div class="row">
                  <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h1.png" alt="2 state of the art clubhouses" class="img-fluid">
                      <h4>2 state of the art clubhouses</h4>
                    </div>
                  </div>
                <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h2.png" alt="O6 acres of forest experience" class="img-fluid">
                      <h4>6 acres of forest experience</h4>
                    </div>
                  </div>
                  <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h3.png" alt="12 acres of park greens" class="img-fluid">
                      <h4>12 acres of park greens</h4>
                    </div>
                  </div>
                  <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h4.png" alt="Banquet Greens" class="img-fluid">
                      <h4>Banquet Greens</h4>
                    </div>
                  </div>
                 <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h5.png" alt="Book Café" class="img-fluid">
                      <h4>Book Café</h4>
                    </div>
                  </div>
                  <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h6.png" alt="Curated Parks" class="img-fluid">
                      <h4>Curated Parks</h4>
                    </div>
                  </div>
                  <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h7.png" alt="Cycling & Jogging Tracks" class="img-fluid">
                      <h4>Cycling & Jogging Tracks</h4>
                    </div>
                  </div>
                 <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h8.png" alt="Green cover with 42,000 trees" class="img-fluid">
                      <h4>Green cover with 42,000 trees</h4>
                    </div>
                  </div>
                  <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h9.png" alt="Organic Farming" class="img-fluid">
                      <h4>Organic Farming</h4>
                    </div>
                  </div>
                 <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h10.png" alt="Plotted development spread over 92.7 acres" class="img-fluid">
                      <h4>Plotted development spread over 92.7 acres</h4>
                    </div>
                  </div>
                 <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h11.png" alt="Retail Plaza" class="img-fluid">
                      <h4>Retail Plaza</h4>
                    </div>
                  </div>
                 <div class="col-md-3 col-6 col-lg-3 ">
                    <div class="highlight-box"> <img src="images/h12.png" alt="Sustainable Infrastructure rainwater harvesting and swales" class="img-fluid">
                       <h4>Sustainable Infrastructure rainwater harvesting and swales</h4>
                     </div>
                   </div>

      <!--              <h2>The IPO-Styled Prelaunch</h2>
                   <ul class="aminties" style="margin: 20px 0; background: #fff; color: #666;  padding: 20px 40px; box-shadow: 0 0 34px -4px #00000069;">
                      <li>Navi Mumbai’s first and biggest ever pre-launch</li>
                       <li>Home buyers can own their residences through an easy payment plan.
Pay only 5% now and the next instalment in 2020*</li>
                      <li>The first time in a private development in Navi Mumbai</li>
                      <li>Unique application-based process</li>
                      <li>Simple and transparent allocation by an automated algorithm</li>
                      <li>Limited unit release for allocation on a first-come-first-serve basis</li>
                 
                    </ul>



<div class="embed-responsive embed-responsive-16by9" style="margin:20px 0">
  <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/JgNOg_xPMfg"></iframe>
</div>


                <h2>Project Highlights</h2>
                  <img src="images/overview-image.jpg" class="img-fluid">
                  <div style="    font-size: 16px;
    color: #8c7066;
    font-weight: 500;
    margin: 10px 0;"> INCREDIBLE LOCATION AND LANDMARK
DEVELOPMENT AT INAUGURAL PRICES</div>
               

                <div  class="row loc-mob">
                  <div class="col-md-12 col-sm-12 ">
                    <ul class="aminties" style="margin: 20px 0; background: #fff; color: #666;  padding: 20px 40px; box-shadow: 0 0 34px -4px #00000069;">
                      <li><span class="headline">Located 5-10 mins from 5 mega projects of Kharghar </span>
                      BKC 2, Metro, Central Park, Golf Course, ISKCON Temple, with easy access to the proposed Airport, Marina & MTHL Sea-Link - a rare location set for exponential growth. </li>
                      <li><span class="headline">Navi Mumbai’s landmark destination</span>Bringing together
 the best of residences, commerce, high-street retail,
 7-star Club and acres of lifestyle amenities - all
 designed and maintained by international experts.</li>
                      <li><span class="headline">IPO of new towers in the most exclusive phase:</span> The
 most premium cluster within the development with
 unique architecture and luxury residences.</li>
                      <li><span class="headline">Exclusive inaugural prices:</span>2 bed residences at Rs 62.99 lacs* and 3 bed residences at Rs 89.56 lacs*
 onwards.</li>
                      <li><span class="headline">Easy payment plan:</span>Flexible payment options with
 attractive financing from major banks.</li>
                      <li><span class="headline">Best time to be part of Navi Mumbai’s newest landmark destination:</span> At an incredible price advantage before it
 heads for explosive growth!</li>
                      
                    </ul>
                  </div>
              
                </div>
                 -->
              
                
              </div>
            </div>
            <hr style="visibility: hidden">
            <h3>About Godrej Properties</h3>
            <div class="row">
              
              <div class="col col-lg-12 col-md-12 ">
                
                <p class="text-justify">Godrej Properties brings the Godrej Group philosophy of innovation, sustainability and excellence to the real estate industry. Each Godrej Properties development combines a 121-year legacy of excellence and trust with a commitment to cutting-edge design and technology. Godrej Properties is currently developing residential, commercial and township projects spread across approximately 14.29 million square meters (150.12 million square feet) in 12 cities.</p>
                 <p class="text-justify">In the last 3 years, Godrej Properties has received over 200 awards and recognitions, including the "Real Estate Company Of The Year" at the Construction Week India Awards 2015, 'Golden Peacock Award for Sustainability' for the year 2015 by Institute Of Directors (IOD), "Most Reliable Builder for 2014" at the CNBC AWAAZ Real Estate Awards 2014, "Innovation Leader in Real Estate" award at the NDTV Property Awards 2014 and "Popular Choice - Developer of the Year" award by ET NOW in 2013.</p>
                
              </div>
            </div>
            
          </div>
        </div>
        <div class="col col-lg-3 col-md-3 sidebar">
        </div>
        <div class="clearfix"></div>
        <!--   <div class="bg-residences">
          <div class="res-content">
            <h2>Luxurious homes with dedicated spaces.</h2>
            <p>Mahindra Roots is a perfect example of a tranquil oasis with high-end amenities and features that is strategically situated off Western Express Highway in Kandivali East - Mumbai, offering unmatched ease. Every home at Roots is a beautiful and spacious retreat, full of possibilities, opulence and qualities, created using the best technology and materials to give the residents a supreme lifestyle.
            </p>
            
            
          </div>
          
        </div> -->
        <!--   <div class="col col-lg-9 col-md-9">
          <div class="wrapper-inner-text" style="margin-top: 20px;">
            <h2>About Mahindra Lifespaces</h2>
            
            <p class="text-justify">Established in 1994, Mahindra Lifespace Developers Ltd. is the real estate and infrastructure development business of the USD 20.7 billion Mahindra Group, and a pioneer of sustainable urbanisation in India. The Company is committed to transforming India’s urban landscape through its residential developments under the ‘Mahindra Lifespaces’ and ‘Happinest’ brands; and through its integrated cities and industrial clusters under the ‘Origins by Mahindra World City’ brand.
            </p>
            <p class="text-justify">Mahindra Lifespaces delivers innovative customer-focused solutions that are rooted in a legacy of trust and transparency. The Company’s development footprint spans 23 million sq. ft. (2.133 million sq. m.) of completed, ongoing and forthcoming residential projects across seven Indian cities; and over 4960 acres of ongoing and forthcoming projects under development/management at its integrated developments in four cities.
            </p>
            <p class="text-justify">A pioneer of the green homes movement in India, Mahindra Lifespaces has been ranked 4th in Asia in its category, in the ‘2017 GRESB Real Estate ESG (Environmental, Social and Governance) Assessment’. The Company has also been ranked among the top 50 great mid-size workplaces in India – 2017, by the Great Places To Work Institute.
            </p>
          </div></div> -->
          <div class="col col-lg-3 col-md-3 sidebar">
          </div>
        </div>
      </section>
      <section class="bg-image2 tracked" id="amenities">
        <div class="container">
          <div class="col-sm-12  col-lg-9 col-md-9 ">
            <div class="wrapper-inner-text">
              <h2>Amenities</h2>
               <p class="text-justify">Discover a place where you can build a home to put down your roots. Step into a life in Devanahalli, Bangalore that is covered with the goodness of fresh air, organic food, and open forest greens. Feel rejuvenated as you engage in health and leisure activities - from ones where you soak in the exquisite views of the Nandi Hills, to ones where you can bask in the luxuries of the club like the Green Terrace, Open-to-sky Sculpture Court, Book Café, and the Sports Zone. Come, experience peace at Godrej Reserve that offers privileges and immense joy for everyone.</p>



              <img src="images/inner-page.jpg" class="img-fluid">
              <div class="row">
                <div class=" col-lg-6 col-md-6 col-sm-12">
                  <ul class="list-group list-group-flush ">
                    <li class="list-group-item">Cafe  </li>
                    <li class="list-group-item">Library  </li>
                    <li class="list-group-item">Retail </li>
                     <li class="list-group-item">Spa </li>
                   </ul>
                 </div>
                 <div class=" col-lg-6 col-md-6 col-sm-12">
                  <ul class="list-group list-group-flush ">
                    <li class="list-group-item">Jogging  </li>
                    <li class="list-group-item">Cycling Track  </li>
                    <li class="list-group-item">Convenience Store  </li>
                    <li class="list-group-item">Curated Parks  </li>
                  </ul>
                  


                </div>
                
                
                
                
              </div>
            </div>
          </div>
          <div class="col col-lg-3 col-md-3 sidebar">
          </div>
        </div>
      </section>
      <section class="bg-image2 tracked" id="plans">
        <div class="container">
          <div class="col-sm-12  col-lg-9 col-md-9 ">
            <div class="wrapper-inner-text">
              <h2>Site and Floor plans</h2>
              
              <div class="row">
                <div class="col col-lg-12 col-md-12">
                  
                  
                  
              <!--     <div style="display: table; margin:auto;">
                    <figure class="snip1205 green">
                      <img src="images/masterplan.jpg" class="img-fluid" alt="" style="width: 400px;">
                      <i class="material-icons">
                      zoom_in
                      </i><a data-fancybox="gallery"  href="images/masterplan.jpg" title="Master Plan"></a></figure> <h5 class="text-center">Master Plan </h5>
                      
                    </div> -->
                    <div class="row justify-content-center ">
                      
                      
                <!--       <div class=" col-lg-6 col-md-6 col-sm-12">
                        <figure class="snip1205 green">
                          <img src="images/1bhk.jpg" class="img-fluid" alt="">
                          <i class="material-icons">
                          zoom_in
                          </i>
                          <a data-toggle="modal" data-target="#floorplan" title="" class=" holder-plans" href="#"></a>
                        </figure> <h5 class="text-center">1 BHK  Unit plan </h5>
                      </div> -->
                      
                      <div class=" col-lg-6 col-md-6 col-sm-12">
                        <figure class="snip1205 green">
                          <img src="images/masterplan.jpg" class="img-fluid" alt="" style="    height: 350px;">
                          <i class="material-icons">
                          zoom_in
                          </i>
                          <a data-toggle="modal" data-target="#floorplan" title="" class=" holder-plans" href="#"></a>
                        </figure> <h5 class="text-center">Layout plan </h5>
                      </div>
               <!--         <div class=" col-lg-4 col-md-4 col-sm-12">
                        <figure class="snip1205 green">
                          <img src="images/4bhk.jpg" class="img-fluid" alt="">
                          <i class="material-icons">
                          zoom_in
                          </i>
                          <a data-toggle="modal" data-target="#floorplan" title="" class=" holder-plans" href="#"></a>
                        </figure> <h5 class="text-center">4 BHK  Unit plan </h5>
                      </div>
                          <div class=" col-lg-4 col-md-4 col-sm-12">
                        <figure class="snip1205 green">
                          <img src="images/4bhk-s.jpg" class="img-fluid" alt="">
                          <i class="material-icons">
                          zoom_in
                          </i>
                          <a data-toggle="modal" data-target="#floorplan" title="" class=" holder-plans" href="#"></a>
                        </figure> <h5 class="text-center">4 BHK Small  Unit plan </h5>
                      </div>
                    </div> -->
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col col-lg-3 col-md-3 sidebar">
            </div>
          </div>
        </section>
        <section class="bg-image2 tracked" id="location">
          <div class="container">
            <div class="col-sm-12  col-lg-9 col-md-9 ">
              <div class="wrapper-inner-text">
                <h2>Location</h2>
                <div class="row">
                  <div class=" col-lg-12 col-md-12">
                        <h1 style="" class="">Godrej Reserve  Devenahalli, Bengaluru  </h1>
                        <p class="text-justify">The location of the project is the main part for any buyer to check if it will be feasible for him to buy a home here. The area Devanahalli is close to all the other areas of the city, and the connectivity of the same is also good by road which proves that property here can prove as a good asset. The buyer of a home here can find leading schools and other educational institutes here. There are also all the required facilities of life such as a hospital, shopping centers, malls, and pharmacies as well as banks in the nearby area to this project. One can also find petrol pumps, ATMs and other day to day items in the vicinity of this project. The project has doubtlessly the benefit of such a leading developer and its experience which can offer a right property at a very right price. As it is in prelaunch status one can find the resident here at low cost as of now.</p>
                        <ul>
                  <li>Proximity to International Airport</li>
                  <li>1.2 km from School</li>
                  <li>1.5 km from Hospital</li>
                  <li>5 km from College</li>
                  <li>8 km from Bus Stand</li>
                  <li>12 km from Railway Station</li>
              </ul>

                    <div class="row">
                 <!--      <div class="col col-lg-6 col-md-6" style="    margin-top: 9px;">
                    
                        
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d224235.79141357154!2d77.22764754544752!3d28.579243059555463!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ceb6e8f91c4d1%3A0x90048eb529829752!2sGodrej+Park+Avenue!5e0!3m2!1sen!2sin!4v1534414639304" width="100%" height="368" frameborder="0" style="border:0" allowfullscreen></iframe>
                   
                         
                        </div> -->
                 <!--          <div class="col col-lg-12 col-md-12">
                                 <div style="display: table; margin:auto;">
                          <figure class="snip1205 green">
                            <img src="images/location.jpg" class="img-fluid" alt="" style="">
                            <i class="material-icons">
                            zoom_in
                            </i><a data-fancybox="gallery"  href="images/location.jpg" title="Location Map"></a></figure> 
                            
                          </div>
                          </div> -->
                      </div>
                    </div>
                  </div>
                  <div class="col col-lg-3 col-md-3 sidebar">
                  </div>
                </div>
              </section>
              <section class="bg-image2 tracked" id="costing">
                <div class="container">
                  <div class="col-sm-12  col-lg-9 col-md-9 ">
                    <div class="wrapper-inner-text">
                      <h2>Costing Details</h2>
                      <div class="row justify-content-center" >
                        
                        <div class="col col-md-6 col-sm-12">
                          
                          <div class="table-responsive">
                            <table class="table table-bordered  table-striped" style="margin-top:10px;">
                              <thead>
                                <tr class="price_head">
                                  <th>Plot Type </th>
                                  <th>Plot Sizes </th>
                                  <th> Price </th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td class="res_head">Nest </td>
                                  <td class="res_head">1200 Sq. ft.  </td>
                                  <td class="">Rs 44 lakhs onwards <br><a data-toggle="modal" data-target="#costingdetails" class="btn button-3d" style="font-size:14px; letter-spacing:0; text-transform:none;">Request Price Breakup</a></td>
                                  <!--  <td class="">Rs 3.4 Lacs </td> -->
                                </tr>
                                <tr>
                                   <td class="res_head">Cottage </td>
                                  <td class="res_head">1500 Sq. ft. </td>
                                  <!--   <td class="res_head">961 sq ft</td> -->
                                  <td class="">Rs 50 lakhs onwards <br><a data-toggle="modal" data-target="#costingdetails" class="btn button-3d" style="font-size:14px; letter-spacing:0; text-transform:none;">Request Price Breakup</a></td>
                                  <!--  <td class="">Rs 3.4 Lacs </td> -->
                                  
                                </tr>
                                  <tr>
                                      <td class="res_head">Bungalow </td>
                                  <td class="res_head">1800 Sq. ft. </td>
                                  <!--   <td class="res_head">961 sq ft</td> -->
                                  <td class="">Rs 65 lakhs onwards <br><a data-toggle="modal" data-target="#costingdetails" class="btn button-3d" style="font-size:14px; letter-spacing:0; text-transform:none;">Request Price Breakup</a></td>
                                  <!--  <td class="">Rs 3.4 Lacs </td> -->
                                  
                                </tr>
                                    <tr>
                                      <td class="res_head">Mansion </td>
                                  <td class="res_head">2400 Sq. ft. </td>
                                  <!--   <td class="res_head">961 sq ft</td> -->
                                  <td class="">Rs 86 lakhs onwards <br><a data-toggle="modal" data-target="#costingdetails" class="btn button-3d" style="font-size:14px; letter-spacing:0; text-transform:none;">Request Price Breakup</a></td>
                                  <!--  <td class="">Rs 3.4 Lacs </td> -->
                                  
                                </tr>
                                      <tr>
                                         <td class="res_head">Estate </td>
                                  <td class="res_head">3200 Sq. ft. </td>
                                  <!--   <td class="res_head">961 sq ft</td> -->
                                  <td class="">Rs 104 lakhs onwards <br><a data-toggle="modal" data-target="#costingdetails" class="btn button-3d" style="font-size:14px; letter-spacing:0; text-transform:none;">Request Price Breakup</a></td>
                                  <!--  <td class="">Rs 3.4 Lacs </td> -->
                                  
                                </tr>

                              </tbody>
                            </table>
                          </div>
                          <!-- <p class="small">#under 5:95 scheme</p> -->
                          
                        </div>
                        <div class="col col-md-6 col-sm-12">
                          
                          <figure class="snip1205 green">
                            <img src="images/costing-details.jpg" class="img-fluid">
                            <i class="material-icons">
                            zoom_in
                            </i>
                            <a data-toggle="modal" data-target="#costingdetails" title="" class=" holder-plans" href="#"></a>
                            </figure>  <a data-toggle="modal" data-target="#costingdetails" class="btn button-3d" style="display: table;margin: auto;">Complete Costing Details</a>
                            
                            
                            
                          </div>
                          <div class="clearfix"></div>
                          
                          
                          
                          
                          
                          
                        </div>
                        <div class="col col-lg-3 col-md-3 sidebar">
                        </div>
                      </div>
                    </section>
                    <section class="bg-image2 tracked" id="virtualtour">
                      <div class="container">
                        <div class="col-sm-12  col-lg-9 col-md-9 ">
                          <div class="wrapper-inner-text">
                            <h2>Virtual Site Tour</h2>
                            <div class="">
                              <div class="">
                                
                                
                                <div class="row" >
                                  
                                  <div class=" " style="display: table; margin: 20px ">
                                    <figure class="snip1205 green">
                                      <img src="images/video-gate.jpg" class="img-fluid" alt="">
                                      <i class="material-icons">
                                      play_circle_outline
                                      </i>
                                      <a data-toggle="modal" data-target="#virtual" title="" class=" holder-plans" href="#"></a>
                                    </figure> <h5 class="text-center">Virtual Site tour to  Godrej Reserve - Devanahalli, Bengaluru  </h5>
                                    
                                    
                                  </div>
                                  
                                  <div class="clearfix"></div>
                                  
                                  
                                  
                                  
                                  
                                  
                                </div>
                                
                              </div>
                            </div>
                            <div class="col col-lg-3 col-md-3 sidebar">
                            </div>
                          </div>
                        </section>
                        <!--Share Details Expert---->
                        <div class="modal hide  fade" id="share" abindex="-1" role="dialog" aria-labelledby="enquirenow" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                              
                              <div class="modal-header">
                                <h5 class="modal-title"><img src="images/logo.jpg" class="img-fluid" alt=" Logo"></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <form method="post" class="signin" action="#" id="query_form_share">
                                  <input type="hidden" id="name_enquiry" name="name_shareh">
                                  
                                  <div class="form-group groupmaterial">
                                    <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="name_share"  required="required">
                                    <span class="highlight"></span>
                                    <span class="bar"></span>
                                    <label for="forname">Name</label>
                                  </div>
                                  <div class="form-group groupmaterial">
                                    <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="contact_share"  required="required">
                                    <span class="highlight"></span>
                                    <span class="bar"></span>
                                    <label for="forname">Mobile Number</label>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                    <button type="submit" name="btnsubmit" class="btn button-3d">Get Instant Call Back</button>
                                    <a href="tel:7506010422" style="    text-align: center;
                                      
                                      color: #000;
                                      font-weight: bold;
                                      /* margin: 0; */
                                      text-decoration: none; float: right;
                                    margin: 8px 0;"><i class="fa fa-phone-square"></i> +91 7506010422</a>
                                  </div>
                                  
                                </form>
                              </div>
                              </div><!-- /.modal-content -->
                              </div><!-- /.modal-dialog -->
                            </div>
                            <!--share Details Expert---->
                            <!--ENQUIRY NOW MODAL FORM-->
<div class="modal fade" id="enquirenow" abindex="-1" role="dialog" aria-labelledby="enquirenow" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title">Mail Me Complete details <span class="small">#</span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" class="signin" action="#" id="query_form_enquiry">
          <input type="hidden" id="name_enquiry" name="name_enquiry">
          
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="name_enq"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Name</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="email_enq"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Email</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="contact_enq"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Mobile Number</label>
          </div>
          <div class="form-group groupmaterial">
            <textarea type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="comments_enq"  required="required"></textarea>
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Comments</label>
          </div>
          
          <div class="form-group">
            <button type="submit" name="btnsubmit" class="btn button-3d">Submit</button>
          </div>
        </form>
      </div>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div>

 <!--ENQUIRY NOW MODAL ENdS FORM-->


  <!--REQUEST PRICE MODAL---->
  <!--ENQUIRY NOW MODAL FORM-->
<div class="modal fade" id="price" abindex="-1" role="dialog" aria-labelledby="enquirenow" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title">Mail Me Pricing details <span class="small">#</span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" class="signin" action="#" id="query_form_price">
          <input type="hidden" id="name_enquiry" name="name_requestprice">
          
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="name_price"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Name</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="email_price"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Email</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="contact_price"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Mobile Number</label>
          </div>
          <div class="form-group groupmaterial">
            <textarea type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="comments_price"  required="required"></textarea>
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Comments</label>
          </div>
          
          <div class="form-group">
            <button type="submit" name="btnsubmit" class="btn button-3d">Submit</button>
          </div>
        </form>
      </div>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div>

<!--REQUEST PRICE MODAL ENDS---->


<!--ORGANIZE SITE VISIT MODAL START---->


<div class="modal fade" id="sitevisit" abindex="-1" role="dialog" aria-labelledby="enquirenow" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title">Organize Site Visit <span class="small">#</span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" class="signin" action="#" id="query_form_sitevisit">
          <input type="hidden" id="name_enquiry" name="name_sitevisit">
          
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="name_visit"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Name</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="email_visit"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Email</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="contact_visit"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Mobile Number</label>
          </div>
          <div class="form-group groupmaterial">
            <textarea type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="comments_visit"  required="required"></textarea>
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Comments</label>
          </div>
          
          <div class="form-group">
            <button type="submit" name="btnsubmit" class="btn button-3d">Submit</button>
          </div>
        </form>
      </div>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div>


<!--ORGANIZE SITE VISIT MODAL ENDS---->
<!--REQUEST CALL BACK MODAL START---->

<a data-toggle="modal" data-target="#call-back"><div class="call-back wow animated fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s"><img src="images/call-back1.png"></div></a>
<div class="modal fade" id="call-back" abindex="-1" role="dialog" aria-labelledby="enquirenow" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title">Immediate call Back <span class="small">#</span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" class="signin" action="#" id="query_form_callback">
          <input type="hidden" id="name_enquiry" name="name_callback">
          
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="name_call"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Name</label>
          </div>
   
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="contact_call"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Mobile Number</label>
          </div>
  
          
          <div class="form-group">
            <button type="submit" name="btnsubmit" class="btn button-3d">Submit</button>
          </div>
        </form>
      </div>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div>

<!--REQUEST CALL BACK MODAL ENDS---->



<!--FLOORPLAN MODAL START---->

<div class="modal fade" id="floorplan" abindex="-1" role="dialog" aria-labelledby="enquirenow" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title">Send Me Floor plan details <span class="small">#</span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" class="signin" action="#" id="query_form_floorplan">
          <input type="hidden" id="name_enquiry" name="name_floorplan">
          
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="name_floor"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Name</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="email_floor"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Email</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="contact_floor"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Mobile Number</label>
          </div>
          <div class="form-group groupmaterial">
            <textarea type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="comments_floor"  required="required"></textarea>
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Comments</label>
          </div>
          
          <div class="form-group">
            <button type="submit" name="btnsubmit" class="btn button-3d">Submit</button>
          </div>
        </form>
      </div>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div>
<!--FLOORPLAN MODAL ENDS---->



<!--COSTING DETAILS MODAL START---->



<div class="modal fade" id="costingdetails" abindex="-1" role="dialog" aria-labelledby="enquirenow" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title">Send Me Costing details <span class="small">#</span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" class="signin" action="#" id="query_form_costingdetails">
          <input type="hidden" id="name_enquiry" name="name_costingdetails">
          
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="name_costing"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Name</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="email_costing"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Email</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="contact_costing"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Mobile Number</label>
          </div>
          <div class="form-group groupmaterial">
            <textarea type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="comments_costing"  required="required"></textarea>
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Comments</label>
          </div>
          
          <div class="form-group">
            <button type="submit" name="btnsubmit" class="btn button-3d">Submit</button>
          </div>
        </form>
      </div>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div>


<!--COSTING DETAILS MODAL ENDS---->
<!--Ebook Download MODAL START---->




<div class="modal fade" id="ebook" abindex="-1" role="dialog" aria-labelledby="enquirenow" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title">Ebook Download <span class="small">#</span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" class="signin" action="#" id="query_form_ebook">
          <input type="hidden" id="name_enquiry" name="name_ebookd">
          
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="name_ebook"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Name</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="email_ebook"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Email</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="contact_ebook"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Mobile Number</label>
          </div>
      <!--     <div class="form-group groupmaterial">
            <textarea type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="comments_ebook"  required="required"></textarea>
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Comments</label>
          </div> -->
          
          <div class="form-group">
            <button type="submit" name="btnsubmit" class="btn button-3d">Email Me ! </button>
          </div>
        </form>
      </div>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div>

<!--Ebook Download MODAL ENDS---->
<!--Virtual TOur MODAL START---->


<div class="modal fade" id="virtual" abindex="-1" role="dialog" aria-labelledby="enquirenow" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title">Virtual Site tour to  Godrej Reserve - Devanahalli, Bengaluru <span class="small">#</span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" class="signin" action="#" id="query_form_virtual">
          <input type="hidden" id="name_enquiry" name="name_virtualt">
          
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="name_virtual"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Name</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="email_virtual"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Email</label>
          </div>
          <div class="form-group groupmaterial">
            <input type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="contact_virtual"  required="required">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Mobile Number</label>
          </div>
          <div class="form-group groupmaterial">
            <textarea type="text" class="form-control" id="forname" aria-describedby="emailHelp" placeholder="" name="comments_virtual"  required="required"></textarea>
            <span class="highlight"></span>
            <span class="bar"></span>
            <label for="forname">Comments</label>
          </div>
          
          <div class="form-group">
            <button type="submit" name="btnsubmit" class="btn button-3d">Submit</button>
          </div>
        </form>
      </div>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div>



<!--Virtual TOur MODAL ENDS---->

<div class="modal fade" id="group" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="close">&times;</span></button>
<h4 class="modal-title">Group Booking </h4>
</div>
<div class="modal-body">
<form method="post" class="signin" action="#" id="query_form_group">
<input type="hidden" id="name_virtualt" name="name_groupm">
<div class="form-group">
<div class="input-group"> <span class="input-group-addon" id="basic-addon1"><i class="fa fa-user"></i></span>
<input type="text"  name="name_group" data-error="Name field is required!" class="form-control" placeholder="Name" aria-describedby="basic-addon1" required>
</div>
</div>
<div class="form-group">
<div class="input-group"> <span class="input-group-addon" id="basic-addon1"><i class="fa fa-envelope"></i></span>
<input type="email"  name="email_group" data-error="Email field is required!" class="form-control" placeholder="Email Id" aria-describedby="basic-addon1" required >
</div>
</div>
<div class="form-group">
<div class="input-group"> <span class="input-group-addon" id="basic-addon1"><i class="fa fa-mobile fa-lg"></i></span>
<input type="tel" id="" name="contact_group" data-error="Contact field is required!" class="form-control" placeholder="Mobile Number" aria-describedby="basic-addon1" required>
</div>
</div>
<div class="form-group">
<div class="input-group"> <span class="input-group-addon" id="basic-addon1"><i class="fa fa-pencil-square-o"></i></span>
<textarea name="comments_group" placeholder="Comments" onkeyup="javascript:return checkTextenqfrm();" class="form-control enqfrm" rows="3" ></textarea>
</div>
</div>
<div class="form-group">
<button type="submit" name="btnsubmit" onclick="validate3(); return false;" class="btn button-3d" style="font-size:15px">Submit</button>
</div>
</form>
</div>
</div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div>
<div class="modal" id="sitee-back" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog">
<div class="modal-content" >
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="close">&times;</span></button>
<h4 class="modal-title">Book  Home Presentation </h4>
</div>
<div class="modal-body">
<form method="post" class="signin" action="#" id="query_form_sitee-back">
<div class="form-group">
<input type="hidden" id="name_appointm" name="name_appointm">
<div class="input-group"> <span class="input-group-addon" id="basic-addon1"><i class="fa fa-user"></i></span>
<input type="text"  name="name_appoint" data-error="Name field is required!" class="form-control" placeholder="Name" aria-describedby="basic-addon1" required>
</div>
</div>
<div class="form-group">
<div class="input-group"> <span class="input-group-addon" id="basic-addon1"><i class="fa fa-envelope"></i></span>
<input type="email"  name="email_appoint" data-error="Email field is required!" class="form-control" placeholder="Email Id" aria-describedby="basic-addon1" required>
</div>
</div>
<div class="form-group">
<div class="input-group"> <span class="input-group-addon" id="basic-addon1"><i class="fa fa-mobile fa-lg"></i></span>
<input type="tel" id="contact_appoint" name="contact_appoint" data-error="Contact field is required!" class="form-control" placeholder="Mobile Number" aria-describedby="basic-addon1" required>
</div>
</div>
<div class="form-group">
<label style="
font-weight: 500;">Need pick up ?</label>
<label style="
font-weight: 500; margin-right:10px">
<input type="radio" name="pickup" class=""  id="noCheck1" onclick="javascript:yesnoCheck1();" checked="" />
No </label>
<label style="
font-weight: 500; ">
<input type="radio" name="pickup" class="" id="yesCheck1" onclick="javascript:yesnoCheck1();"/>
Yes </label>
<div class="" id="ifYes" style="display:none; margin-top:5px;">
<div class="form-group">
<div class="input-group"> <span class="input-group-addon " id="basic-addon1"><i class="fa fa-calendar"></i></span>
<input type="text" name="date_appoint" class="form-control" id="crsdob" data-date="" data-date-format="dd MM yyyy" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd"  placeholder="Choose Date & time" required>
</div>
</div>
</div>
</div>
<div class="form-group">
<div class="input-group"> <span class="input-group-addon" id="basic-addon1"><i class="fa fa-pencil-square-o"></i></span>
<textarea name="comments_appoint" placeholder="Comments" onkeyup="javascript:return checkTextenqfrm();" class="form-control enqfrm" rows="3" ></textarea>
</div>
</div>
<div class="form-group">
<button type="submit" name="btnsubmit" onclick="validate3(); return false;" class="btn button-3d">Submit</button>
</div>
</form>
</div>
</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>

<!-- <div class="running-car "><div class="animated infinite slideInLeft" style="animation-duration: 3s"> <a data-toggle="modal" data-target="#sitevisit" href="#">
<img class="car" src="images/car.png" alt=""></a>
<img class="wheel animated infinite rotateOut" src="images/car-tier.png" alt="" style="animation-duration: 1s">
</div>
</div> -->                            <footer >
                              <div class=" footer-bot">
                                <div class=" col-12 col-sm-12 col-xs-12">
                                 <div class="footer-copy"><strong>Disclaimer:</strong>The content is for information purposes only and does not constitute an offer to avail of any service. Prices mentioned are subject to change without notice and properties mentioned are subject to availability. Images for representation purpose only. This is not the official website. Website maintained by online marketing agency. We may share data with rera registered brokers/companies for further processing. We may also send updates to the mobile number/email id registered with us. All Rights Reserved. <br>
                                    # The said proposed project is under final approval stage submitted with competent authorities. You will receive complete details only after necessary approvals. At this stage this is not an offer to sell just collection of preliminary intrest to better manage demand after launch.  


                                  </div>
                                  </div>
                                </div>
                              </div>
                            </footer>
                      <div class="mob-box ">
                        <div class="btn-group btn-group-justified">
                            <a data-toggle="modal" data-target="#sitevisit" class="btn btn-default btn-bottom hide-mob"><i class="fa fa-phone" aria-hidden="true" style="display: table; margin: auto;"></i>
                              Organize Site Visit </a>
                            <a href="https://api.whatsapp.com/send?phone=917506010422&text=Hi%20I'm%20interested%20in%20Godrej%20Reserve%20Devanahalli%20at%20Bengaluru" class="btn btn-default btn-bottom"><i class="fa fa-whatsapp" aria-hidden="true" style="display: table; margin: auto;"></i> <img src="images/whatsapp.png">
                             <span class="small">+ 91 7506010422</span></a>
                            <a href="tel:7506010422" class="btn btn-default btn-bottom  show-mob hide-big"><i class="fa fa-phone-square" aria-hidden="true" style="display: table; margin: auto;"></i>
                        &nbsp; Tap to Call </a>
                        </div>
                      </div>
                      <div class="mob-box-show ">
                      <ul class="nav  nav-fill">
                        <li class="nav-item">
                          <a href="https://api.whatsapp.com/send?phone=917506010422&text=Hi%20I'm%20interested%20in%20Godrej%20Reserve%20Devanahalli%20at%20Bengaluru" class="nav-link "> <img src="images/whatsapp.png">
                             <span class="small">+ 91 7506010422</span></a>
                        </li>
                        <li class="nav-item">
                           <a href="tel:7506010422" class="nav-link  ">
                        &nbsp; Tap to Call </a>
                        </li>

                      </ul>
                      </div>
                                <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
                                <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha384-tsQFqpEReu7ZLhBV2VZlAu7zcOV+rXbYlF2cqB8txI/8aZajjp4Bqd+V6D5IgvKT" crossorigin="anonymous"></script>
                                <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" ></script>
                                <script src="js/bootstrap.min.js" ></script>
                                <script src="js/wow.js"></script>
                                <script src="js/jquery.nicescroll.js"></script>
                                <script  src="js/fancybox-n/jquery.fancybox.min.js"></script>
                                <script src="js/stickyNav.js"></script>
                                <script type="text/javascript">
                                $(document).ready(function() {
                                  $('.stickyMenu').smoothMenu({
                                    menuSpeedAnimate: 300,
                                    stickyMenu: false,
                                    slidingLine: false,
                                    winMobWidth:768,
                                  });
                                });
                                $('.navbar-nav>li>a').on('click', function(){
                                 $('.navbar-collapse').collapse('hide');
                                });


                                $(document).ready(function() {
                                  $('.stickyMenum').smoothMenu({
                                    menuSpeedAnimate: 300,
                                    stickyMenu: false,
                                    slidingLine: false,
                                    winMobWidth:768,
                                  });
                                });
                                $('.navbar-nav>li>a').on('click', function(){
                                 $('.navbar-collapse').collapse('hide');
                                });

                              </script>
                                <script>
                                new WOW().init();
                                //nice scroll
                                $("html").niceScroll({cursorwidth:"7px"});
                                $('.fancybox').fancybox();
                                $(".hover").mouseleave(
                                function () {
                                $(this).removeClass("hover");
                                }
                                );
                                </script>
                                <script type="text/javascript">
                                window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set._.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
                                $.src="//v2.zopim.com/?3cQBoFplIdumhew779oMP9Z74YIjvGyO";z.t=+new Date;$.type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
                                $zopim(function(){
                                window.setTimeout(function() {
                                $zopim.livechat.window.show();
                                }, 30000);
                                $zopim.livechat.window.setOffsetHorizontal(5);
                                $zopim.livechat.window.setOffsetVertical(0);
                                $zopim.livechat.theme.setColor('#78a940');
                                $zopim.livechat.window.setSize('small')
                                });
                                </script>
                                <script type="text/javascript">
                                $(window).on('load',function(){
                                      setTimeout(function(){
                                      $('#share').modal('show');
                                      }, 15000);
                                    });
                                 //nice scroll
                                $("html").niceScroll({cursorwidth:"7px"});
                                </script>
                                <script type="text/javascript">
                                // function yesnoCheck1() {
                                //   if (document.getElementById('yesCheck1').checked) {
                                //       document.getElementById('ifYes').style.display = 'block';
                                //   }
                                //   else document.getElementById('ifYes').style.display = 'none';
                                // }
                                // $(function () {
                                //   $("#crsdob").datetimepicker({
                                //     format: "dd MM yyyy - hh:ii",
                                //     autoclose: true,
                                //     todayBtn: true,
                                //     pickerPosition: "bottom-left"
                                //   });
                                // });
                                // $(window).load(function(){
                                //   setTimeout(function(){
                                //     if(!$("#enquirenow.modal").hasClass("in") && !$("#ebook.modal").hasClass("in") && !$("#sitevisit.modal").hasClass("in") && !$("#call-back.modal").hasClass("in") && !$("#costingdetails").hasClass("in")){
                                //        $('#share').modal('show');
                                //     }
                                //   }, 10000);
                                // });
                                </script>
                                <script type="text/javascript">
                                   $(document).on('click', '#mainNav li', function() {
                                       $("#mainNav li").removeClass("active");
                                       $(this).addClass("active");
                                   });
                                </script>

                              </body>
                            </html>